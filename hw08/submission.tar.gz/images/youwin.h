/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 youwin youwin.png 
 * Time-stamp: Thursday 11/11/2021, 02:08:45
 * 
 * Image Information
 * -----------------
 * youwin.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef YOUWIN_H
#define YOUWIN_H

extern const unsigned short youwin[38400];
#define YOUWIN_SIZE 76800
#define YOUWIN_LENGTH 38400
#define YOUWIN_WIDTH 240
#define YOUWIN_HEIGHT 160

#endif

