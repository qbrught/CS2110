/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 ggbro ggbroski.png 
 * Time-stamp: Thursday 11/11/2021, 01:18:03
 * 
 * Image Information
 * -----------------
 * ggbroski.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GGBRO_H
#define GGBRO_H

extern const unsigned short ggbroski[38400];
#define GGBROSKI_SIZE 76800
#define GGBROSKI_LENGTH 38400
#define GGBROSKI_WIDTH 240
#define GGBROSKI_HEIGHT 160

#endif

