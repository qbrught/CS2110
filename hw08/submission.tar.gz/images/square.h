/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 square square.png 
 * Time-stamp: Thursday 11/11/2021, 00:08:07
 * 
 * Image Information
 * -----------------
 * square.png 2400@2400
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SQUARE_H
#define SQUARE_H

extern const unsigned short square[5760000];
#define SQUARE_SIZE 11520000
#define SQUARE_LENGTH 5760000
#define SQUARE_WIDTH 2400
#define SQUARE_HEIGHT 2400

#endif

