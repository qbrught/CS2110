/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 circle circle.png 
 * Time-stamp: Thursday 11/11/2021, 00:14:03
 * 
 * Image Information
 * -----------------
 * circle.png 677@677
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CIRCLE_H
#define CIRCLE_H

extern const unsigned short circle[458329];
#define CIRCLE_SIZE 916658
#define CIRCLE_LENGTH 458329
#define CIRCLE_WIDTH 677
#define CIRCLE_HEIGHT 677

#endif

