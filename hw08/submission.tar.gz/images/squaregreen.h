/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 squaregreen squaregreen.png 
 * Time-stamp: Thursday 11/11/2021, 00:13:30
 * 
 * Image Information
 * -----------------
 * squaregreen.png 256@256
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SQUAREGREEN_H
#define SQUAREGREEN_H

extern const unsigned short squaregreen[65536];
#define SQUAREGREEN_SIZE 131072
#define SQUAREGREEN_LENGTH 65536
#define SQUAREGREEN_WIDTH 256
#define SQUAREGREEN_HEIGHT 256

#endif

