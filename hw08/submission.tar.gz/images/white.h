/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 white white.jpeg 
 * Time-stamp: Thursday 11/11/2021, 00:13:03
 * 
 * Image Information
 * -----------------
 * white.jpeg 1200@703
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WHITE_H
#define WHITE_H

extern const unsigned short white[843600];
#define WHITE_SIZE 1687200
#define WHITE_LENGTH 843600
#define WHITE_WIDTH 1200
#define WHITE_HEIGHT 703

#endif

