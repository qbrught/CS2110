/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 easygame easygame.jpeg 
 * Time-stamp: Thursday 11/11/2021, 01:14:32
 * 
 * Image Information
 * -----------------
 * easygame.jpeg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef EASYGAME_H
#define EASYGAME_H

extern const unsigned short easygame[38400];
#define EASYGAME_SIZE 76800
#define EASYGAME_LENGTH 38400
#define EASYGAME_WIDTH 240
#define EASYGAME_HEIGHT 160

#endif

